//404 page

import react from 'react';

const PageNotFound = () => {
    return (
        <main>
            <div>Page Not Found</div>
        </main>
    );
}

export default PageNotFound;